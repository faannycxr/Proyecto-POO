package com.mycompany.proyectofinalpoo12eq02;

public class empleados extends datosPersonas {

    public empleados(String nombre, String apellidoPaterno, String apellidoMaterno,
                     String direccion, String correo, String celular,
                     String rfc, String numeroTrabajador,
                     String tipoTrabajador, String sucursal, 
                     String id, String contrasenia) {

        super(nombre, apellidoPaterno, apellidoMaterno, direccion, celular, correo,
              rfc, numeroTrabajador, tipoTrabajador, sucursal, id, contrasenia);
    }
}
