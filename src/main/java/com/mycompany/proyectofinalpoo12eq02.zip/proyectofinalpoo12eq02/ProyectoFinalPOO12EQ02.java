
package com.mycompany.proyectofinalpoo12eq02;

public class ProyectoFinalPOO12EQ02 {

    public static void main(String[] args) {
        AcercaDe.mostrarAcercaDe();
        cambiarPagina.saltoPagina();        
        cambiarPagina.Carga();
        cambiarPagina.saltoPagina();        

        MenuClienteNoRegistrado.MenuInicial();

    }
}
