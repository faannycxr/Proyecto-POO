package com.mycompany.proyectofinalpoo12eq02;

public class datosPersonas {

    protected String nombre;
    protected String apellidoPaterno;
    protected String apellidoMaterno;
    protected String direccion;
    protected String celular;
    protected String correo;
    
    // Campos exclusivos de empleados
    protected String rfc;
    protected String numeroTrabajador;
    protected String tipoTrabajador;
    protected String sucursal;
    
    protected String id;
    protected String contrasenia;

    public datosPersonas() {
    }

    public datosPersonas(String nombre, String apellidoPaterno, String apellidoMaterno, String direccion,
                         String celular, String correo, String rfc, String numeroTrabajador,
                         String tipoTrabajador, String sucursal, String id, String contrasenia) {

        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.direccion = direccion;
        this.celular = celular;
        this.correo = correo;

        this.rfc = rfc;
        this.numeroTrabajador = numeroTrabajador;
        this.tipoTrabajador = tipoTrabajador;
        this.sucursal = sucursal;

        this.id = id;
        this.contrasenia = contrasenia;
    }

        public String getNombre() {
        return nombre;
        }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getNumeroTrabajador() {
        return numeroTrabajador;
    }

    public void setNumeroTrabajador(String numeroTrabajador) {
        this.numeroTrabajador = numeroTrabajador;
    }

    public String getTipoTrabajador() {
        return tipoTrabajador;
    }

    public void setTipoTrabajador(String tipoTrabajador) {
        this.tipoTrabajador = tipoTrabajador;
    }

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    }
