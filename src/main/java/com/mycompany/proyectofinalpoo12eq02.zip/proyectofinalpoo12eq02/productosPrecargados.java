package com.mycompany.proyectofinalpoo12eq02;

import java.util.ArrayList;

public class productosPrecargados {

    private ArrayList<productos> listaProductos;

    public productosPrecargados() {
        listaProductos = new ArrayList<>();
        cargarProductos();
    }

    private void cargarProductos() {

        // 1. Refresco Grande
        productos pr1 = new productos(
            "Refresco Grande",
            75007614,
            85,
            "Bebidas",
            50,
            110,
            52,
            200,
            78
        );
        listaProductos.add(pr1);

        // 2. Refresco Mediano
        productos pr2 = new productos(
            "Refresco Mediano",
            75007615,
            65,
            "Bebidas",
            80,
            110,
            5,
            200,
            122
        );
        listaProductos.add(pr2);

        // 3. ICEE
        productos pr3 = new productos(
            "ICEE",
            75007616,
            95,
            "Bebidas",
            0,
            80,
            44,
            100,
            50
        );
        listaProductos.add(pr3);

        // 4. Palomitas Jumbo
        productos pr4 = new productos(
            "Palomitas Jumbo",
            75007624,
            100,
            "Botana",
            130,
            200,
            120,
            263,
            300
        );
        listaProductos.add(pr4);

        // 5. Palomitas Grandes
        productos pr5 = new productos(
            "Palomitas Grandes",
            75007617,
            85,
            "Botana",
            93,
            45,
            31,
            143,
            98
        );
        listaProductos.add(pr5);

        // 6. Palomitas Medianas
        productos pr6 = new productos(
            "Palomitas Medianas",
            75007618,
            60,
            "Botana",
            72,
            13,
            65,
            112,
            210
        );
        listaProductos.add(pr6);

        // 7. Hotdog
        productos pr7 = new productos(
            "Hotdog",
            75007619,
            60,
            "Comida",
            37,
            25,
            80,
            99,
            75
        );
        listaProductos.add(pr7);

        // 8. Nachos
        productos pr8 = new productos(
            "Nachos",
            75007620,
            70,
            "Comida",
            63,
            30,
            305,
            210,
            181
        );
        listaProductos.add(pr8);

        // 9. Nerds
        productos pr9 = new productos(
            "Nerds",
            75007621,
            45,
            "Dulces",
            90,
            90,
            0,
            90,
            8
        );
        listaProductos.add(pr9);

        // 10. M&M's
        productos pr10 = new productos(
            "M&M's",
            75007622,
            53,
            "Dulces",
            130,
            45,
            3,
            0,
            42
        );
        listaProductos.add(pr10);

        // 11. Peluche Rob
        productos pr11 = new productos(
            "Peluche Rob",
            75007623,
            450,
            "Recuerdos",
            5,
            35,
            43,
            89,
            32
        );
        listaProductos.add(pr11);

        // 12. Emperador
        productos pr12 = new productos(
            "Emperador",
            75007625,
            35,
            "Galletas",
            80,
            220,
            139,
            213,
            115
        );
        listaProductos.add(pr12);

        // 13. Palomera
        productos pr13 = new productos(
            "Palomera",
            75007626,
            210,
            "Recuerdos",
            120,
            120,
            120,
            120,
            20
        );
        listaProductos.add(pr13);
    }

    public ArrayList<productos> getProductos() {
        return listaProductos;
    }
}
