package com.mycompany.proyectofinalpoo12eq02;

public class Sucursales {

    private Sucursal cu = new Sucursal("CU");
    private Sucursal universidad = new Sucursal("Universidad");
    private Sucursal delta = new Sucursal("Delta");
    private Sucursal xochimilco = new Sucursal("Xochimilco");
    private Sucursal polanco = new Sucursal("Polanco");

    public Sucursal getCU() {
        return cu;
    }

    public Sucursal getUniversidad() {
        return universidad;
    }

    public Sucursal getDelta() {
        return delta;
    }

    public Sucursal getXochimilco() {
        return xochimilco;
    }

    public Sucursal getPolanco() {
        return polanco;
    }
}
