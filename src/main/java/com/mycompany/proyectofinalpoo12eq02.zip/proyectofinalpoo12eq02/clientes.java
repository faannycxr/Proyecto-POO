package com.mycompany.proyectofinalpoo12eq02;

public class clientes extends datosPersonas {

    public clientes(String nombre, String apellidoPaterno, String apellidoMaterno,
                    String direccion, String celular, String correo,
                    String id, String contrasenia) {

        super(nombre, apellidoPaterno, apellidoMaterno, direccion, celular, correo,
              null, null, null, null, id, contrasenia);
    }
}
