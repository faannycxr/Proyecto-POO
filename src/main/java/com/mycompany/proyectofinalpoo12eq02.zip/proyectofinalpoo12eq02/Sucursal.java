
package com.mycompany.proyectofinalpoo12eq02;

import java.util.ArrayList;
import java.util.List;

public class Sucursal {

    private final String nombre;
    private final List<Cartelera> cartelera = new ArrayList<>();

    public Sucursal(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Cartelera> getCartelera() {
        return cartelera;
    }

    public void agregarCartelera(Cartelera c) {
        if (c != null) {
            cartelera.add(c);
        }
    }

    public void imprimirCarteleras() {
        if (cartelera.isEmpty()) {
            System.out.println("No hay funciones disponibles en " + nombre + ".");
            return;
        }
        System.out.println("Funciones en " + nombre + ":");
        for (Cartelera c : cartelera) {
            c.imprimirCartelera();
        }
    }
}
