/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinalpoo12eq02;


public class AcercaDe {
        public static void mostrarAcercaDe() {

    System.out.println("Programacion Orientada a objetos\n");
    System.out.println("Grupo 12\nSemestre 2026-1");
    System.out.println("Equipo ##\n //nombre del equipo //CAMBIAR"); //no se que equipo somos :(
    System.out.println("Integrantes:\nCabanzo Lopez Jose de Jesus.   322138915");
        System.out.println("Desarrollo: ");
    System.out.println("Camacho Ramos Paola Estefany.   #########"); //pongan sus numeros de cuenta, no los pide, pero siento que quedaria bn, o si no, avisenme para quitar el mio xd
        System.out.println("Desarrollo: ");
    System.out.println("Cuevas Lopez Jose Roberto.   #########");
        System.out.println("Desarrollo: ");
    System.out.println("Luis Ortiz Deborah Patricia.   #########");
        System.out.println("Desarrollo: ");
    System.out.println("Vargas de la Cruz Alan.   #########");    
        System.out.println("Desarrollo: "); 
}
}


